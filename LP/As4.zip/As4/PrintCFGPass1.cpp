#include "llvm/IR/PassManager.h"
#include "llvm/IR/Function.h"
#include "llvm/IR/Instructions.h"
#include "llvm/IR/Module.h"
#include "llvm/Passes/PassPlugin.h"
#include "llvm/Support/raw_ostream.h"
#include "llvm/Passes/PassBuilder.h"
#include <set>
#include <string>
#include <vector>
#include <map>
#include <algorithm>
#include <sstream>

using namespace llvm;

struct PrintCFGPass : PassInfoMixin<PrintCFGPass> {
    PreservedAnalyses run(Function &F, FunctionAnalysisManager &) {
        errs() << "Function: " << F.getName() << "\n";

        // First pass: collect all expressions across all blocks
        std::set<std::string> allExprs;
        for (auto &BB : F) {
            for (auto &I : BB) {
                if (auto *BI = dyn_cast<BinaryOperator>(&I)) {
                    std::string lhs = BI->getOperand(0)->getName().str();
                    std::string rhs = BI->getOperand(1)->getName().str();
                    std::string op = BI->getOpcodeName();
                    std::string expr = lhs + " " + op + " " + rhs;
                    allExprs.insert(expr);
                }
            }
        }

        std::map<std::string, int> exprToIndex;
        std::vector<std::string> indexToExpr;
        int idx = 0;
        for (const auto &e : allExprs) {
            exprToIndex[e] = idx++;
            indexToExpr.push_back(e);
        }

        for (auto &BB : F) {
            errs() << "BasicBlock: " << BB.getName() << "\n";
            std::set<std::string> genSet;
            std::set<std::string> killSet;
            std::set<std::string> definedVars;

            for (auto IIt = BB.begin(); IIt != BB.end(); ++IIt) {
                Instruction &I = *IIt;
                errs() << "  Instruction: " << I << "\n";

                if (auto *BI = dyn_cast<BinaryOperator>(&I)) {
                    std::string lhs = BI->getOperand(0)->getName().str();
                    std::string rhs = BI->getOperand(1)->getName().str();
                    std::string op = BI->getOpcodeName();
                    std::string expr = lhs + " " + op + " " + rhs;

                    // Look ahead for redefinitions of lhs or rhs
                    bool lhsRedefinedLater = false;
                    bool rhsRedefinedLater = false;

                    for (auto LookAhead = std::next(IIt); LookAhead != BB.end(); ++LookAhead) {
                        if (LookAhead->hasName()) {
                            std::string name = LookAhead->getName().str();
                            if (name == lhs) lhsRedefinedLater = true;
                            if (name == rhs) rhsRedefinedLater = true;
                        }
                    }

                    if (!lhsRedefinedLater && !rhsRedefinedLater) {
                        genSet.insert(expr);
                    }
                }

                if (I.hasName()) {
                    std::string def = I.getName().str();
                    definedVars.insert(def);
                }
            }

            // ✅ KILL set logic: any expr with a redefined operand
            for (const auto &expr : allExprs) {
                std::istringstream iss(expr);
                std::string lhs, op, rhs;
                iss >> lhs >> op >> rhs;

                if (definedVars.count(lhs) || definedVars.count(rhs)) {
                    killSet.insert(expr);
                }
            }

            // Print GEN set
            errs() << "  GEN: { ";
            for (const auto &e : genSet) errs() << e << " ";
            errs() << "}\n";

            // Print KILL set
            errs() << "  KILL: { ";
            for (const auto &e : killSet) errs() << e << " ";
            errs() << "}\n";

            // BitVectors
            std::vector<int> genBits(indexToExpr.size(), 0);
            std::vector<int> killBits(indexToExpr.size(), 0);

            for (const auto &e : genSet) genBits[exprToIndex[e]] = 1;
            for (const auto &e : killSet) killBits[exprToIndex[e]] = 1;

            errs() << "  GEN BitVector: ";
            for (int b : genBits) errs() << b;
            errs() << "\n";

            errs() << "  KILL BitVector: ";
            for (int b : killBits) errs() << b;
            errs() << "\n";
        }

        return PreservedAnalyses::all();
    }
};

extern "C" LLVM_ATTRIBUTE_WEAK ::llvm::PassPluginLibraryInfo llvmGetPassPluginInfo() {
    return {
        LLVM_PLUGIN_API_VERSION, "PrintCFGPass", LLVM_VERSION_STRING,
        [](PassBuilder &PB) {
            PB.registerPipelineParsingCallback(
                [](StringRef Name, FunctionPassManager &FPM,
                   ArrayRef<PassBuilder::PipelineElement>) {
                    if (Name == "print-cfg") {
                        FPM.addPass(PrintCFGPass());
                        return true;
                    }
                    return false;
                });
        }};
}

