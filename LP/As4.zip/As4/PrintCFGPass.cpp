#include "llvm/IR/PassManager.h"
#include "llvm/IR/Function.h"
#include "llvm/IR/Instructions.h"
#include "llvm/IR/Module.h"
#include "llvm/Passes/PassPlugin.h"
#include "llvm/Support/raw_ostream.h"
#include "llvm/Passes/PassBuilder.h"
#include <set>

using namespace llvm;

struct PrintCFGPass : PassInfoMixin<PrintCFGPass> {
    PreservedAnalyses run(Function &F, FunctionAnalysisManager &) {
        errs() << "Function: " << F.getName() << "\n";

        for (auto &BB : F) {
            errs() << "BasicBlock: " << BB.getName() << "\n";

            std::set<const Value*> Gen;
            std::set<const Value*> Kill;
            std::set<const Value*> DefinedInBlock;

            for (auto &I : BB) {
                errs() << "  Instruction: " << I << "\n";

                // If this instruction defines a value (non-void), add to Kill and Defined
                if (!I.getType()->isVoidTy()) {
                    Kill.insert(&I);
                    DefinedInBlock.insert(&I);
                }

                // Check operands (uses)
                for (unsigned i = 0; i < I.getNumOperands(); ++i) {
                    Value *operand = I.getOperand(i);
                    if (isa<Constant>(operand)) continue;

                    if (DefinedInBlock.find(operand) == DefinedInBlock.end()) {
                        Gen.insert(operand);
                    }
                }
            }

            // Print GEN set
            errs() << "  GEN: { ";
            for (auto *v : Gen) {
                if (v->hasName()) errs() << v->getName() << " ";
                else v->printAsOperand(errs(), false);
                errs() << " ";
            }
            errs() << "}\n";

            // Print KILL set
            errs() << "  KILL: { ";
            for (auto *v : Kill) {
                if (v->hasName()) errs() << v->getName() << " ";
                else v->printAsOperand(errs(), false);
                errs() << " ";
            }
            errs() << "}\n";
        }

        return PreservedAnalyses::all();
    }
};

// Register the pass with the new PassManager
extern "C" LLVM_ATTRIBUTE_WEAK ::llvm::PassPluginLibraryInfo llvmGetPassPluginInfo() {
    return {
        LLVM_PLUGIN_API_VERSION, "PrintCFGPass", LLVM_VERSION_STRING,
        [](PassBuilder &PB) {
            PB.registerPipelineParsingCallback(
                [](StringRef Name, FunctionPassManager &FPM,
                   ArrayRef<PassBuilder::PipelineElement>) {
                    if (Name == "print-cfg") {
                        FPM.addPass(PrintCFGPass());
                        return true;
                    }
                    return false;
                });
        }};
}
