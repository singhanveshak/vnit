#include "llvm/IR/PassManager.h"
#include "llvm/IR/Function.h"
#include "llvm/IR/Instructions.h"
#include "llvm/Passes/PassPlugin.h"
#include "llvm/Support/raw_ostream.h"
#include "llvm/Passes/PassBuilder.h"
#include <set>
#include <string>
#include <map>
#include <vector>
#include <regex>

using namespace llvm;

struct PrintCFGPass : PassInfoMixin<PrintCFGPass> {
    PreservedAnalyses run(Function &F, FunctionAnalysisManager &) {
        errs() << "Function: " << F.getName() << "\n";

        // Tracks all definitions of each variable globally (e.g., all x0, x1 for x)
        std::map<std::string, std::set<std::string>> allDefs;

        // Iterate over basic blocks to compute GEN and KILL
        for (auto &BB : F) {
            errs() << "BasicBlock: " << BB.getName() << "\n";

            std::map<std::string, std::string> latestDef; // var -> latest SSA name in block
            std::set<std::string> definedVars;            // variables defined in block

            // Track all instructions in the block
            for (auto &I : BB) {
                errs() << "  Instruction: " << I << "\n";

                if (I.hasName()) {
                    std::string name = I.getName().str();

                    // Match SSA pattern like x0, y1, etc.
                    std::smatch match;
                    if (std::regex_match(name, match, std::regex("^([a-zA-Z]+)(\\d+)$"))) {
                        std::string base = match[1];

                        allDefs[base].insert(name);        // Add to global def set
                        latestDef[base] = name;            // Overwrite to keep latest in block
                        definedVars.insert(base);          // Mark base as defined
                    }
                }
            }

            // Construct GEN and KILL
            std::set<std::string> GEN, KILL;

            // GEN = last SSA def per variable in this block
            for (const auto &[base, ssa] : latestDef) {
                GEN.insert(ssa);
            }

            // KILL = all SSA defs of any variable defined in this block
            for (const auto &var : definedVars) {
                for (const auto &def : allDefs[var]) {
                    KILL.insert(def);
                }
            }

            // Print GEN
            errs() << "  GEN: { ";
            for (const auto &v : GEN) errs() << v << " ";
            errs() << "}\n";

            // Print KILL
            errs() << "  KILL: { ";
            for (const auto &v : KILL) errs() << v << " ";
            errs() << "}\n";
        }

        return PreservedAnalyses::all();
    }
};

// Required pass registration boilerplate
extern "C" LLVM_ATTRIBUTE_WEAK ::llvm::PassPluginLibraryInfo llvmGetPassPluginInfo() {
    return {
        LLVM_PLUGIN_API_VERSION, "PrintCFGPass", LLVM_VERSION_STRING,
        [](PassBuilder &PB) {
            PB.registerPipelineParsingCallback(
                [](StringRef Name, FunctionPassManager &FPM,
                   ArrayRef<PassBuilder::PipelineElement>) {
                    if (Name == "print-cfg") {
                        FPM.addPass(PrintCFGPass());
                        return true;
                    }
                    return false;
                });
        }};
}



