#include <iostream.h>
#define A 13

int main(){

int ali = 5;
int b = a -12;

//Single line

/*
Multi
Line
*/

if(b > 7 )
{
return 1;
}

return 0;
}

