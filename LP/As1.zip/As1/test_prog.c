#include <iostream.h>

int main(){
int a = 2;
int b = a + 3;
printf("%d",b);
//hello
/*hi i am happy*/
for(int i=0;i<3;i++){printf("\nhello");}
}

