#include <iostream.h>

int main(){
int a = 2;
int b = a + 3;
printf("%d",b);
}

/**
singhanveshak:~/CS/LP/As1$ gcc lex.yy.c -o out -lfl
singhanveshak:~/CS/LP/As1$ ./out < test_prog.c 
Integers: 2
Floating-point numbers: 0

**/
