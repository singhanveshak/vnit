import cv2
import numpy as np
import matplotlib.pyplot as plt

# Load images
scene = cv2.imread("img61.jpg")
object_img = cv2.imread("Sample_Image.jpg")

# Convert object image to grayscale and create a binary mask
gray_object = cv2.cvtColor(object_img, cv2.COLOR_BGR2GRAY)
_, mask = cv2.threshold(gray_object, 10, 255, cv2.THRESH_BINARY)

# Convert mask to 3 channels to match scene ROI
mask_3ch = cv2.merge([mask, mask, mask])

# Get dimensions of the object image
obj_h, obj_w = object_img.shape[:2]

# Define position to place the object in the scene
x_offset, y_offset = 100, 50  # Adjust as needed

# Create ROI (Region of Interest) in the scene
roi = scene[y_offset:y_offset+obj_h, x_offset:x_offset+obj_w]

# Use bitwise operations to combine images
scene_bg = cv2.bitwise_and(roi, roi, mask=cv2.bitwise_not(mask_3ch))  # Remove object area from scene
object_fg = cv2.bitwise_and(object_img, object_img, mask=mask_3ch)  # Keep only object

# Combine both parts
combined = cv2.add(scene_bg, object_fg)
scene[y_offset:y_offset+obj_h, x_offset:x_offset+obj_w] = combined  # Place composite in scene

# Display results
plt.figure(figsize=(12, 6))

plt.subplot(1, 3, 1)
plt.imshow(cv2.cvtColor(scene, cv2.COLOR_BGR2RGB))
plt.title("Scene Image")
plt.axis("off")

plt.subplot(1, 3, 2)
plt.imshow(cv2.cvtColor(object_img, cv2.COLOR_BGR2RGB))
plt.title("Object Image")
plt.axis("off")

plt.subplot(1, 3, 3)
plt.imshow(cv2.cvtColor(scene, cv2.COLOR_BGR2RGB))
plt.title("Composite Image")
plt.axis("off")

plt.show()
