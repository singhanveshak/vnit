import cv2
import numpy as np
import matplotlib.pyplot as plt

# Load images
noise_img = cv2.imread("noise.tif", 0)  # Load in grayscale
car_img = cv2.imread("car.png", 0)

# Define filter kernels
avg_kernel_3x3 = np.ones((3, 3), np.float32) / 9  # Simple averaging kernel
avg_kernel_5x5 = np.ones((5, 5), np.float32) / 25  # Larger averaging kernel
weighted_kernel = np.array([[1, 2, 1], 
                            [2, 4, 2], 
                            [1, 2, 1]], np.float32) / 16  # Gaussian-like weighted kernel

# Apply filters (Manual Convolution using cv2.filter2D)
avg_3x3 = cv2.filter2D(noise_img, -1, avg_kernel_3x3)
avg_5x5 = cv2.filter2D(noise_img, -1, avg_kernel_5x5)
weighted_avg = cv2.filter2D(noise_img, -1, weighted_kernel)

# Apply Median filters
median_3x3 = cv2.medianBlur(noise_img, 3)
median_5x5 = cv2.medianBlur(noise_img, 5)

# Plot results
plt.figure(figsize=(12, 8))

plt.subplot(2, 3, 1)
plt.imshow(noise_img, cmap="gray")
plt.title("Original: noise.tiff")
plt.axis("off")

plt.subplot(2, 3, 2)
plt.imshow(avg_3x3, cmap="gray")
plt.title("Averaging 3x3")
plt.axis("off")

plt.subplot(2, 3, 3)
plt.imshow(avg_5x5, cmap="gray")
plt.title("Averaging 5x5")
plt.axis("off")

plt.subplot(2, 3, 4)
plt.imshow(weighted_avg, cmap="gray")
plt.title("Weighted Averaging")
plt.axis("off")

plt.subplot(2, 3, 5)
plt.imshow(median_3x3, cmap="gray")
plt.title("Median 3x3")
plt.axis("off")

plt.subplot(2, 3, 6)
plt.imshow(median_5x5, cmap="gray")
plt.title("Median 5x5")
plt.axis("off")

plt.tight_layout()
plt.show()

# Finding optimum kernel size for noise reduction
for k in range(3, 11, 2):  # Trying different kernel sizes (odd numbers)
    median_filtered = cv2.medianBlur(noise_img, k)
    cv2.imshow(f"Median Filter {k}x{k}", median_filtered)

cv2.waitKey(0)
cv2.destroyAllWindows()
