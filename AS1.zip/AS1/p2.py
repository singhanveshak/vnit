import cv2
import numpy as np
import matplotlib.pyplot as plt

# Load images
image = cv2.imread("hills.jpeg")
template = cv2.imread("template.png", 0)  # Convert template to grayscale
gray_image = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)  # Convert main image to grayscale

# Template matching using normalized cross-correlation
result = cv2.matchTemplate(gray_image, template, cv2.TM_CCOEFF_NORMED)

# Find the best match location
min_val, max_val, min_loc, max_loc = cv2.minMaxLoc(result)
top_left = max_loc
h, w = template.shape  # Template dimensions

# Draw rectangle around matched region
matched_image = image.copy()
cv2.rectangle(matched_image, top_left, (top_left[0] + w, top_left[1] + h), (0, 255, 0), 3)

# Plot results
plt.figure(figsize=(12, 6))

plt.subplot(1, 2, 1)
plt.imshow(result, cmap="jet")
plt.title("Template Matching Result")
plt.axis("off")

plt.subplot(1, 2, 2)
plt.imshow(cv2.cvtColor(matched_image, cv2.COLOR_BGR2RGB))
plt.title("Detected Template")
plt.axis("off")

plt.show()
