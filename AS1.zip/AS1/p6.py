import cv2
import numpy as np
import matplotlib.pyplot as plt

# Load image
image = cv2.imread("coins.jpeg", 0)  # Convert to grayscale

# Normalize the image to [0,1]
image = image.astype(np.float32) / 255.0

# Morphological gradient (Edge detection using dilation - erosion)
kernel = np.ones((3, 3), np.uint8)
morph_gradient = cv2.morphologyEx(image, cv2.MORPH_GRADIENT, kernel)

# Top-hat transformation (bright regions)
tophat = cv2.morphologyEx(image, cv2.MORPH_TOPHAT, kernel)

# Black-hat transformation (dark regions)
blackhat = cv2.morphologyEx(image, cv2.MORPH_BLACKHAT, kernel)

# Canny Edge Detection (for comparison)
canny_edges = cv2.Canny((image * 255).astype(np.uint8), 100, 200)

# Display results
plt.figure(figsize=(12, 8))

plt.subplot(2, 3, 1)
plt.imshow(image, cmap="gray")
plt.title("Original Image")
plt.axis("off")

plt.subplot(2, 3, 2)
plt.imshow(morph_gradient, cmap="gray")
plt.title("Morphological Gradient")
plt.axis("off")

plt.subplot(2, 3, 3)
plt.imshow(tophat, cmap="gray")
plt.title("Top-Hat Transform")
plt.axis("off")

plt.subplot(2, 3, 4)
plt.imshow(blackhat, cmap="gray")
plt.title("Black-Hat Transform")
plt.axis("off")

plt.subplot(2, 3, 5)
plt.imshow(canny_edges, cmap="gray")
plt.title("Canny Edge Detector")
plt.axis("off")

plt.tight_layout()
plt.show()
