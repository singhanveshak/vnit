import cv2
import numpy as np
import matplotlib.pyplot as plt

# Function for gamma correction
def gamma_correction(image, gamma):
    inv_gamma = 1.0 / gamma
    table = np.array([(i / 255.0) ** inv_gamma * 255 for i in range(256)]).astype("uint8")
    return cv2.LUT(image, table)

# Load images
home = cv2.imread("home.jpg", 0)  # Load in grayscale
sunset = cv2.imread("sunset.jpg")

# Histogram Equalization on "home.jpg"
hist_eq = cv2.equalizeHist(home)

# Gamma Correction on "sunset.jpg" with different gamma values
gamma_values = [0.5, 1.5, 2.2]
gamma_corrected_images = [gamma_correction(sunset, g) for g in gamma_values]

# Histogram Equalization on "sunset.jpg"
sunset_gray = cv2.cvtColor(sunset, cv2.COLOR_BGR2GRAY)
sunset_hist_eq = cv2.equalizeHist(sunset_gray)

# Plot results
plt.figure(figsize=(12, 8))

# Original and Histogram Equalized images of "home.jpg"
plt.subplot(2, 3, 1)
plt.imshow(home, cmap="gray")
plt.title("Original: home.jpg")
plt.axis("off")

plt.subplot(2, 3, 2)
plt.imshow(hist_eq, cmap="gray")
plt.title("Histogram Equalized: home.jpg")
plt.axis("off")

# Original and Gamma Corrected "sunset.jpg"
plt.subplot(2, 3, 3)
plt.imshow(cv2.cvtColor(sunset, cv2.COLOR_BGR2RGB))
plt.title("Original: sunset.jpg")
plt.axis("off")

for i, (gamma, img) in enumerate(zip(gamma_values, gamma_corrected_images), start=4):
    plt.subplot(2, 3, i)
    plt.imshow(cv2.cvtColor(img, cv2.COLOR_BGR2RGB))
    plt.title(f"Gamma: {gamma}")
    plt.axis("off")

plt.subplot(2, 3, 6)
plt.imshow(sunset_hist_eq, cmap="gray")
plt.title("Histogram Equalized: sunset.jpg")
plt.axis("off")

plt.tight_layout()
plt.show()
