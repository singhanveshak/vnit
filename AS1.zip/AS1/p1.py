import cv2
import numpy as np
import matplotlib.pyplot as plt

# Load the image
image = cv2.imread("Lenna.png")
image = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)  # Convert to RGB

# Define scaling factors
scale_factor = 2  # Increase size by 2x
new_size = (image.shape[1] * scale_factor, image.shape[0] * scale_factor)

# Nearest-Neighbor Interpolation
nearest = cv2.resize(image, new_size, interpolation=cv2.INTER_NEAREST)

# Bilinear Interpolation
bilinear = cv2.resize(image, new_size, interpolation=cv2.INTER_LINEAR)

# Plot the images
plt.figure(figsize=(12, 6))

plt.subplot(1, 3, 1)
plt.imshow(image)
plt.title("Original Image")
plt.axis("off")

plt.subplot(1, 3, 2)
plt.imshow(nearest)
plt.title("Nearest Neighbor Interpolation")
plt.axis("off")

plt.subplot(1, 3, 3)
plt.imshow(bilinear)
plt.title("Bilinear Interpolation")
plt.axis("off")

plt.show()
