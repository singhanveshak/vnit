#include <gmp.h>
#include <stdio.h>

void compute_gcd(mpz_t result, const mpz_t a, const mpz_t b) {
    mpz_t x, y, temp;
    mpz_init_set(x, a); // Initialize x = a
    mpz_init_set(y, b); // Initialize y = b
    mpz_init(temp);     // Temporary variable for swapping

    while (mpz_sgn(y) != 0) { // While y ≠ 0
        mpz_set(temp, y);     // temp = y
        mpz_mod(y, x, y);     // y = x mod y
        mpz_set(x, temp);     // x = temp
    }

    mpz_set(result, x);       // GCD is in x

    mpz_clear(x);
    mpz_clear(y);
    mpz_clear(temp);
}

int main() {
    mpz_t a, b, gcd;

    mpz_init(a);
    mpz_init(b);
    mpz_init(gcd);

    // Set large numbers a and b
    mpz_set_str(a, "123456789012345678901234567890", 10);
    mpz_set_str(b, "987654321098765432109876543210", 10);

    compute_gcd(gcd, a, b);

    gmp_printf("GCD of %Zd and %Zd is %Zd\n", a, b, gcd);

    mpz_clear(a);
    mpz_clear(b);
    mpz_clear(gcd);
    return 0;
}
