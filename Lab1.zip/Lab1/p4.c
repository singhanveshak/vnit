#include <gmp.h>

int main() {
    mpz_t random;
    gmp_randstate_t rstate;

    mpz_init(random);
    gmp_randinit_default(rstate);
    gmp_randseed_ui(rstate, 123456); // Seed for reproducibility

    mpz_urandomb(random, rstate, 16); // Generate a 16-bit random number

    gmp_printf("Random number: %Zd\n", random);

    mpz_clear(random);
    gmp_randclear(rstate);
    return 0;
}
