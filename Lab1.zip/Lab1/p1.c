#include<gmp.h>
int main() {
mpq_t x;
mpq_init(x);
gmp_printf("Hello world, the default value initialized is :%Zd\n", x);
}
