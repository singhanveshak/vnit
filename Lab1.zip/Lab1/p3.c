#include<gmp.h>
#include<stdio.h> 
int main () {
mpz_t num,facto;
mpz_inits(facto, num);
unsigned long int u;
printf("\nEnter the number :\n");
gmp_scanf("%Zd",num);
u=mpz_get_ui(num);
printf("\n The number entered is : %lu", u);
mpz_fac_ui(facto, mpz_get_ui(num));
gmp_printf("\nThe factorial is :\n %Zd\n", facto);
}
