#include <gmp.h>
#include <stdio.h>

void extended_gcd(mpz_t gcd, mpz_t x, mpz_t y, const mpz_t a, const mpz_t b) {
    mpz_t r, r_prev, s, s_prev, t, t_prev, quotient, temp;

    // Initialize variables
    mpz_init_set(r_prev, a);  // r_prev = a
    mpz_init_set(r, b);       // r = b
    mpz_init_set_si(s_prev, 1); // s_prev = 1
    mpz_init_set_si(s, 0);      // s = 0
    mpz_init_set_si(t_prev, 0); // t_prev = 0
    mpz_init_set_si(t, 1);      // t = 1
    mpz_init(quotient);
    mpz_init(temp);

    while (mpz_sgn(r) != 0) { // While r ≠ 0
        mpz_fdiv_q(quotient, r_prev, r); // quotient = r_prev / r (floor division)

        // Update r and r_prev
        mpz_set(temp, r);
        mpz_submul(temp, quotient, r); // temp = r_prev - quotient * r
        mpz_set(r_prev, r);
        mpz_set(r, temp);

        // Update s and s_prev
        mpz_set(temp, s);
        mpz_submul(temp, quotient, s); // temp = s_prev - quotient * s
        mpz_set(s_prev, s);
        mpz_set(s, temp);

        // Update t and t_prev
        mpz_set(temp, t);
        mpz_submul(temp, quotient, t); // temp = t_prev - quotient * t
        mpz_set(t_prev, t);
        mpz_set(t, temp);
    }

    // Set outputs: gcd = r_prev, x = s_prev, y = t_prev
    mpz_set(gcd, r_prev);
    mpz_set(x, s_prev);
    mpz_set(y, t_prev);

    // Clear temporary variables
    mpz_clear(r);
    mpz_clear(r_prev);
    mpz_clear(s);
    mpz_clear(s_prev);
    mpz_clear(t);
    mpz_clear(t_prev);
    mpz_clear(quotient);
    mpz_clear(temp);
}

int main() {
    mpz_t a, b, gcd, x, y;

    mpz_init(a);
    mpz_init(b);
    mpz_init(gcd);
    mpz_init(x);
    mpz_init(y);

    // Set input values
    mpz_set_str(a, "123456789012345678901234567890", 10);
    mpz_set_str(b, "987654321098765432109876543210", 10);

    // Compute extended GCD
    extended_gcd(gcd, x, y, a, b);

    // Print results
    gmp_printf("GCD: %Zd\n", gcd);
    gmp_printf("x: %Zd\n", x);
    gmp_printf("y: %Zd\n", y);
    gmp_printf("Verification: a*x + b*y = %Zd\n", gcd);

    // Clear variables
    mpz_clear(a);
    mpz_clear(b);
    mpz_clear(gcd);
    mpz_clear(x);
    mpz_clear(y);

    return 0;
}
