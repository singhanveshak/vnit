#include<gmp.h>
#include<stdio.h>
int main () {
mpz_t m, n;
mpz_init(m);
mpz_init(n);
printf("Enter the first number\n");
gmp_scanf("%Zd",m);
printf("\nEnter the second number\n");
gmp_scanf("%Zd",n);
mpz_mul(m, m, n); //calling predefined function
gmp_printf("\nThe multiplication of the two numbers is :\n%Zd\n", m);
}
