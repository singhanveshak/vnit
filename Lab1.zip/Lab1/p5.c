#include <gmp.h>
#include <stdio.h>
#include <stdlib.h>

void generate_random_primes(mp_bitcnt_t bit_length, unsigned int n) {
    mpz_t random, prime;
    gmp_randstate_t rstate;

    mpz_init(random);
    mpz_init(prime);
    gmp_randinit_default(rstate);
    gmp_randseed_ui(rstate, time(NULL)); // Seed with current time

    for (unsigned int i = 0; i < n; i++) {
        do {
            mpz_urandomb(random, rstate, bit_length); // Generate random number
        } while (!mpz_probab_prime_p(random, 25));   // Test for primality (25 iterations)

        mpz_set(prime, random);                     // Store the prime
        gmp_printf("Prime %u: %Zd\n", i + 1, prime);
    }

    mpz_clear(random);
    mpz_clear(prime);
    gmp_randclear(rstate);
}

int main() {
    unsigned int n = 5;          // Number of primes
    mp_bitcnt_t bit_length = 16; // Bit length of primes

    generate_random_primes(bit_length, n);
    return 0;
}
