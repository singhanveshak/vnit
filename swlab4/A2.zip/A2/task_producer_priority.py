import pika

connection = pika.BlockingConnection(pika.ConnectionParameters('localhost'))
channel = connection.channel()

# Declare a priority queue with max priority of 10
args = {"x-max-priority": 10}
channel.queue_declare(queue='priority_queue', durable=True, arguments=args)

messages = [
    ("High Priority Task", 10),
    ("Medium Priority Task", 5),
    ("Low Priority Task", 1)
]

for msg, priority in messages:
    channel.basic_publish(
        exchange='',
        routing_key='priority_queue',
        body=msg,
        properties=pika.BasicProperties(
            priority=priority,
            delivery_mode=2  # Make messages persistent
        )
    )
    print(f"Sent: {msg} with priority {priority}")

connection.close()

