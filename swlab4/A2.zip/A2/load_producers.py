import pika
import time

connection = pika.BlockingConnection(pika.ConnectionParameters('localhost'))
channel = connection.channel()

# Declare a queue
channel.queue_declare(queue='task_queue', durable=True)

for i in range(100):  # Simulate 100 tasks
    message = f"Task {i+1}"
    channel.basic_publish(
        exchange='',
        routing_key='task_queue',
        body=message,
        properties=pika.BasicProperties(delivery_mode=2)  # Make message persistent
    )
    print(f"Sent: {message}")
    time.sleep(0.1)  # Simulate slight delay

connection.close()

