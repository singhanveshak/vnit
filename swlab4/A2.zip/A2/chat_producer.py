import pika

connection = pika.BlockingConnection(pika.ConnectionParameters('localhost'))
channel = connection.channel()

# Declare an exchange of type 'fanout'
channel.exchange_declare(exchange='chat_room', exchange_type='fanout')

while True:
    message = input("Enter message (or 'exit' to quit): ")
    if message.lower() == 'exit':
        break
    channel.basic_publish(exchange='chat_room', routing_key='', body=message)
    print(f"Sent: {message}")

connection.close()

