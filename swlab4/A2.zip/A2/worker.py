import pika
import time
import random

connection = pika.BlockingConnection(pika.ConnectionParameters('localhost'))
channel = connection.channel()

# Declare the queue
channel.queue_declare(queue='task_queue', durable=True)

def callback(ch, method, properties, body):
    print(f"Processing: {body.decode()}")
    time.sleep(random.randint(1, 3))  # Simulate random processing time
    print(f"Done: {body.decode()}")
    ch.basic_ack(delivery_tag=method.delivery_tag)  # Acknowledge message

channel.basic_qos(prefetch_count=1)  # Ensure fair distribution
channel.basic_consume(queue='task_queue', on_message_callback=callback)

print("Worker is waiting for tasks...")
channel.start_consuming()

