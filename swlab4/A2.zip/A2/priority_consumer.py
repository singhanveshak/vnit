import pika

connection = pika.BlockingConnection(pika.ConnectionParameters('localhost'))
channel = connection.channel()

channel.queue_declare(queue='priority_queue', durable=True)

def callback(ch, method, properties, body):
    print(f"Processing: {body.decode()}")
    ch.basic_ack(delivery_tag=method.delivery_tag)  # Acknowledge message

channel.basic_consume(queue='priority_queue', on_message_callback=callback)

print("Waiting for messages...")
channel.start_consuming()

