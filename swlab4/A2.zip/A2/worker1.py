import pika
import time
import random

connection = pika.BlockingConnection(pika.ConnectionParameters('localhost'))
channel = connection.channel()

channel.queue_declare(queue='task_queue', durable=True)

def callback(ch, method, properties, body):
    task = body.decode()
    print(f"Worker 1 processing: {task}")
    time.sleep(random.randint(1, 5))  # Simulating processing time
    print(f"Worker 1 completed: {task}")
    ch.basic_ack(delivery_tag=method.delivery_tag)  # Acknowledge message

channel.basic_qos(prefetch_count=1)
channel.basic_consume(queue='task_queue', on_message_callback=callback)

print("Worker 1 waiting for tasks...")
channel.start_consuming()

