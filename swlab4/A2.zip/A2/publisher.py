import pika
import time

connection = pika.BlockingConnection(pika.ConnectionParameters('localhost'))
channel = connection.channel()

channel.exchange_declare(exchange='logs', exchange_type='fanout')

for i in range(1, 6):
    message = f"Update {i}"
    channel.basic_publish(exchange='logs', routing_key='', body=message)
    print(f"Sent: {message}")
    time.sleep(1)

connection.close()

