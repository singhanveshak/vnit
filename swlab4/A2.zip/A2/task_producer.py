import pika
import time

connection = pika.BlockingConnection(pika.ConnectionParameters('localhost'))
channel = connection.channel()

channel.queue_declare(queue='task_queue', durable=True)

tasks = ["Task 1: Process File A", "Task 2: Process File B", "Task 3: Process File C"]

for task in tasks:
    channel.basic_publish(exchange='',
                          routing_key='task_queue',
                          body=task,
                          properties=pika.BasicProperties(delivery_mode=2))  # Make message persistent
    print(f"Sent: {task}")
    time.sleep(1)

connection.close()

