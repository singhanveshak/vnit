import cv2
import numpy as np
import matplotlib.pyplot as plt

# Load images
img1 = cv2.imread("image1.png", cv2.IMREAD_GRAYSCALE)
img2 = cv2.imread("image2.png", cv2.IMREAD_GRAYSCALE)

# Initialize SIFT detector
sift = cv2.SIFT_create()

# Detect keypoints and compute descriptors
kp1, des1 = sift.detectAndCompute(img1, None)
kp2, des2 = sift.detectAndCompute(img2, None)

# Use Brute-Force Matcher
bf = cv2.BFMatcher(cv2.NORM_L2, crossCheck=True)

# Match descriptors
matches = bf.match(des1, des2)

# Sort matches by distance (lower distance = better match)
matches = sorted(matches, key=lambda x: x.distance)

# Draw the top matches
result_img = cv2.drawMatches(img1, kp1, img2, kp2, matches[:50], None, flags=cv2.DrawMatchesFlags_NOT_DRAW_SINGLE_POINTS)

# Show result
plt.figure(figsize=(12, 6))
plt.imshow(result_img, cmap="gray")
plt.title("Feature Matching using SIFT and Brute-Force")
plt.axis("off")
plt.show()
