import cv2
import numpy as np

def kmeans_segmentation(image, k=3):
    img = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    pixels = img.reshape(-1, 1).astype(np.float32)
    _, labels, centers = cv2.kmeans(pixels, k, None, (cv2.TERM_CRITERIA_EPS + cv2.TERM_CRITERIA_MAX_ITER, 10, 1.0), 10, cv2.KMEANS_RANDOM_CENTERS)
    segmented = centers[labels.flatten()].reshape(img.shape)
    return segmented.astype(np.uint8)

def mean_shift_segmentation(image):
    img = cv2.pyrMeanShiftFiltering(image, 20, 40)
    return cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)

def otsu_thresholding(image):
    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    _, otsu = cv2.threshold(gray, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
    return otsu

image1 = cv2.imread("white-flower.png")
image2 = cv2.imread("butterfly.jpg")

kmeans_result = kmeans_segmentation(image1)
mean_shift_result = mean_shift_segmentation(image1)
otsu_result = otsu_thresholding(image1)

cv2.imwrite("kmeans_flower.png", kmeans_result)
cv2.imwrite("meanshift_flower.png", mean_shift_result)
cv2.imwrite("otsu_flower.png", otsu_result)
