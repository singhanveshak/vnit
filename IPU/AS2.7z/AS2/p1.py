import cv2
import numpy as np
from matplotlib import pyplot as plt

# Load image
def load_image(path):
    img = cv2.imread(path, cv2.IMREAD_GRAYSCALE)
    return img

# Apply morphological top-hat transformation
def top_hat_preprocessing(img, kernel_size=15):
    kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (kernel_size, kernel_size))
    top_hat = cv2.morphologyEx(img, cv2.MORPH_TOPHAT, kernel)
    return top_hat

# Apply global thresholding
def global_thresholding(img):
    _, thresh = cv2.threshold(img, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
    return thresh

# Main function
def main():
    image_path = "morf_test.png"
    img = load_image(image_path)
    
    # Apply top-hat transformation
    top_hat_img = top_hat_preprocessing(img)
    
    # Subtract estimated background
    enhanced_img = cv2.subtract(img, top_hat_img)
    
    # Apply global thresholding
    thresholded_img = global_thresholding(enhanced_img)
    
    # Display results
    titles = ["Original Image", "Top-Hat Image", "Enhanced Image", "Thresholded Image"]
    images = [img, top_hat_img, enhanced_img, thresholded_img]
    
    for i in range(4):
        plt.subplot(2, 2, i+1)
        plt.imshow(images[i], cmap='gray')
        plt.title(titles[i])
        plt.axis("off")
    
    plt.show()

if __name__ == "__main__":
    main()
