import cv2
import numpy as np
import matplotlib.pyplot as plt

def rgb2hsi(image):
    image = image.astype(np.float32) / 255.0
    R, G, B = cv2.split(image)

    # Intensity calculation
    I = (R + G + B) / 3.0

    # Saturation calculation
    min_RGB = np.minimum(np.minimum(R, G), B)
    S = 1 - (3 / (R + G + B + 1e-6)) * min_RGB
    S[I == 0] = 0  # Avoid division errors

    # Hue calculation
    numerator = 0.5 * ((R - G) + (R - B))
    denominator = np.sqrt((R - G) ** 2 + (R - B) * (G - B)) + 1e-6
    theta = np.arccos(numerator / denominator)
    
    H = np.where(B > G, 2 * np.pi - theta, theta)  # Adjust for B > G case
    H /= 2 * np.pi  # Normalize to [0,1]

    return H, S, I

# Load image
image = cv2.imread("camel.png")
image = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)

# Convert to HSI
H, S, I = rgb2hsi(image)

# Convert using OpenCV (alternative)
hsv_image = cv2.cvtColor(image, cv2.COLOR_RGB2HSV).astype(np.float32) / 255.0
H_opencv, S_opencv, I_opencv = cv2.split(hsv_image)

# Compute difference images
H_diff = np.abs(H - H_opencv)
S_diff = np.abs(S - S_opencv)
I_diff = np.abs(I - I_opencv)

# Display results
fig, axes = plt.subplots(3, 3, figsize=(12, 9))
titles = ["Hue (Custom)", "Saturation (Custom)", "Intensity (Custom)", 
          "Hue (OpenCV)", "Saturation (OpenCV)", "Intensity (OpenCV)", 
          "Hue Difference", "Saturation Difference", "Intensity Difference"]
images = [H, S, I, H_opencv, S_opencv, I_opencv, H_diff, S_diff, I_diff]

for ax, img, title in zip(axes.flatten(), images, titles):
    ax.imshow(img, cmap="gray")
    ax.set_title(title)
    ax.axis("off")

plt.tight_layout()
plt.show()
