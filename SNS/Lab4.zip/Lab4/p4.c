#include <stdio.h>
#include <string.h>
#include <gmp.h>

#define MAX 256  // Buffer size

// Function to compute modular exponentiation: (base^exp) % mod
void mod_exp(mpz_t result, mpz_t base, mpz_t exp, mpz_t mod) {
    mpz_powm(result, base, exp, mod);
}

// Function to generate an RSA key pair (public and private keys)
void generate_rsa_keys(mpz_t n, mpz_t e, mpz_t d) {
    mpz_t p, q, phi, temp;
    mpz_inits(p, q, phi, temp, NULL);

    mpz_set_str(p, "101", 10);  // Prime number p
    mpz_set_str(q, "103", 10);  // Prime number q

    // Compute n = p * q
    mpz_mul(n, p, q);

    // Compute φ(n) = (p-1) * (q-1)
    mpz_sub_ui(p, p, 1);
    mpz_sub_ui(q, q, 1);
    mpz_mul(phi, p, q);

    // Public exponent e (common choice)
    mpz_set_ui(e, 65537);

    // Compute private exponent d = e^(-1) mod φ(n)
    mpz_invert(d, e, phi);

    mpz_clears(p, q, phi, temp, NULL);
}

// Function to sign a digital certificate (RSA Signature)
void sign_certificate(mpz_t signature, mpz_t message, mpz_t d, mpz_t n) {
    mod_exp(signature, message, d, n);
}

// Function to verify a digital certificate
int verify_certificate(mpz_t signature, mpz_t original_msg, mpz_t e, mpz_t n) {
    mpz_t decrypted;
    mpz_init(decrypted);

    mod_exp(decrypted, signature, e, n);

    // Check if decrypted message matches original
    int is_valid = (mpz_cmp(decrypted, original_msg) == 0);
    mpz_clear(decrypted);
    return is_valid;
}

// Main function: Simulating Certificate Authority (CA)
int main() {
    mpz_t n, e, d, message, signature;
    mpz_inits(n, e, d, message, signature, NULL);

    // Step 1: Generate RSA Key Pair (Public & Private Keys)
    generate_rsa_keys(n, e, d);
    
    // Step 2: Define a message (certificate data)
    mpz_set_str(message, "12345", 10);  // Example certificate data

    printf("Certificate Data: ");
    mpz_out_str(stdout, 10, message);
    printf("\n");

    // Step 3: Sign the certificate (CA signs it)
    sign_certificate(signature, message, d, n);

    printf("Signed Certificate (Signature): ");
    mpz_out_str(stdout, 10, signature);
    printf("\n");

    // Step 4: Verify the certificate
    int valid = verify_certificate(signature, message, e, n);

    printf("Certificate Verification: %s\n", valid ? "VALID" : "INVALID");

    mpz_clears(n, e, d, message, signature, NULL);
    return 0;
}
