#include <stdio.h>
#include <string.h>
#include <gmp.h>

#define MAX 256  // Buffer size for encryption

// Simple XOR-based encryption function (placeholder for a proper symmetric cipher)
void symmetric_encrypt(char *output, const char *input, const char *key) {
    size_t len = strlen(input);
    size_t key_len = strlen(key);

    for (size_t i = 0; i < len; i++) {
        output[i] = input[i] ^ key[i % key_len];
    }
    output[len] = '\0';  // Null-terminate the output
}

// Simulating Needham–Schroeder Key Exchange
int main() {
    char alice_key[MAX] = "alice_secret_key";
    char bob_key[MAX] = "bob_secret_key";
    char kdc_key[MAX] = "kdc_master_key";

    char nonce_alice[MAX] = "123456";  // Random nonce by Alice
    char session_key[MAX] = "session_key_abc"; // New session key

    char ticket[MAX], ticket_decrypted[MAX];
    char message1[MAX], message2[MAX], message3[MAX], message4[MAX];

    printf("Step 1: Alice requests session key from KDC\n");

    // KDC creates a ticket for Bob, encrypting session key with Bob's key
    symmetric_encrypt(ticket, session_key, bob_key);
    printf("Generated Ticket for Bob: %s\n", ticket);

    // KDC responds to Alice with:
    // - Session Key (encrypted with Alice's key)
    // - Ticket (for Bob)
    symmetric_encrypt(message1, session_key, alice_key);
    printf("KDC to Alice: Encrypted Session Key: %s\n", message1);

    printf("\nStep 2: Alice forwards Ticket to Bob\n");

    // Alice sends Ticket to Bob (Bob decrypts it using his key)
    symmetric_encrypt(ticket_decrypted, ticket, bob_key);
    printf("Bob Decrypts Ticket: %s\n", ticket_decrypted);

    printf("\nStep 3: Bob confirms session key by sending encrypted nonce back to Alice\n");

    // Bob encrypts a new message with the session key
    symmetric_encrypt(message2, nonce_alice, session_key);
    printf("Bob to Alice: Encrypted Nonce: %s\n", message2);

    // Alice decrypts it and confirms by modifying it and sending it back
    symmetric_encrypt(message3, message2, session_key);
    printf("Alice to Bob: Confirmed Encrypted Nonce: %s\n", message3);

    printf("\nSecure communication established using Session Key: %s\n", session_key);

    return 0;
}
