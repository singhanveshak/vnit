#include <stdio.h>
#include <gmp.h>

// Function to compute (base^exp) % mod using GMP
void mod_exp(mpz_t result, mpz_t base, mpz_t exp, mpz_t mod) {
    mpz_powm(result, base, exp, mod);
}

int main() {
    mpz_t p, g, a, b, A, B, keyA, keyB;
    
    // Initialize GMP variables
    mpz_inits(p, g, a, b, A, B, keyA, keyB, NULL);

    // Set values for prime p and generator g
    mpz_set_str(p, "23", 10);  // Example prime number
    mpz_set_str(g, "5", 10);   // Primitive root of p

    // Private keys (randomly chosen by Alice and Bob)
    mpz_set_str(a, "6", 10);  // Alice's private key
    mpz_set_str(b, "15", 10); // Bob's private key

    // Compute public keys: A = g^a mod p, B = g^b mod p
    mod_exp(A, g, a, p);
    mod_exp(B, g, b, p);

    // Compute shared secret key: keyA = B^a mod p, keyB = A^b mod p
    mod_exp(keyA, B, a, p);
    mod_exp(keyB, A, b, p);

    // Print results
    gmp_printf("Prime (p): %Zd\n", p);
    gmp_printf("Generator (g): %Zd\n", g);
    gmp_printf("Alice's Private Key (a): %Zd\n", a);
    gmp_printf("Bob's Private Key (b): %Zd\n", b);
    gmp_printf("Alice's Public Key (A): %Zd\n", A);
    gmp_printf("Bob's Public Key (B): %Zd\n", B);
    gmp_printf("Shared Secret Key computed by Alice: %Zd\n", keyA);
    gmp_printf("Shared Secret Key computed by Bob: %Zd\n", keyB);

    // Clear memory
    mpz_clears(p, g, a, b, A, B, keyA, keyB, NULL);

    return 0;
}
