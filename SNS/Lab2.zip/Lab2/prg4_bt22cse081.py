def gcd(a, b):
    while b:
        a, b = b, a % b
    return a

def rrsm_and_totient(m):
    rrsm = []
    for i in range(1, m):
        if gcd(i, m) == 1:
            rrsm.append(i)
    phi = len(rrsm)
    return rrsm, phi

# Input and Output
m = int(input("Enter an integer m: "))

if m <= 0:
    print("Error: Enter a positive integer.")
else:
    rrsm, phi = rrsm_and_totient(m)
    print("RRSM_m:", *rrsm)
    print(f"φ({m}): {phi}")
