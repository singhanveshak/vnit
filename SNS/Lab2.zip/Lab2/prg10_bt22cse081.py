def gcd(a, b):
    while b:
        a, b = b, a % b
    return a

def is_primitive_root(a, m):
    if gcd(a, m) != 1:
        return False  # a must be coprime with m
    powers = set()
    current = a
    for i in range(1, m):
        if current in powers:
            return False  # If a power repeats, a is not a primitive root
        powers.add(current)
        current = (current * a) % m
    return len(powers) == m - 1  # a is primitive root if it generates all numbers from 1 to m-1

def primitive_roots(m):
    roots = []
    for a in range(1, m):
        if is_primitive_root(a, m):
            roots.append(a)
    return roots

# Input and Output
m = int(input("Enter modulus m: "))

if m <= 0:
    print("Error: Modulus m must be positive.")
else:
    roots = primitive_roots(m)
    if roots:
        print(f"The primitive roots of {m} are:", *roots)
        print(f"Total number of primitive roots: {len(roots)}")
    else:
        print(f"There are no primitive roots for {m}.")
