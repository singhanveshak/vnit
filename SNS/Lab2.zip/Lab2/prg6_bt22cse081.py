def gcd_extended(a, b):
    x0, x1, y0, y1 = 1, 0, 0, 1
    while b != 0:
        q = a // b
        a, b = b, a % b
        x0, x1 = x1, x0 - q * x1
        y0, y1 = y1, y0 - q * y1
    return a, x0, y0

def find_multiplicative_inverse(a, m):
    gcd, x, _ = gcd_extended(a, m)
    if gcd != 1:  # Inverse does not exist if gcd(a, m) != 1
        return None
    return x % m  # Ensure the result is positive

# Input and Output
a = int(input("Enter integer a: "))
m = int(input("Enter modulus m: "))

if m <= 0:
    print("Error: Modulus m must be positive.")
else:
    inverse = find_multiplicative_inverse(a, m)
    if inverse is None:
        print(f"The multiplicative inverse of {a} modulo {m} does not exist.")
    else:
        print(f"The multiplicative inverse of {a} modulo {m} is {inverse}.")
        
        
'''
The Extended Euclidean Algorithm finds xx and yy such that:
ax+my=gcd⁡(a,m)
ax+my=gcd(a,m)

    If gcd⁡(a,m)=1gcd(a,m)=1, then xx (mod mm) is the inverse.
'''
