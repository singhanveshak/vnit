def gcd_extended(a, b):
    x0, x1, y0, y1 = 1, 0, 0, 1
    while b != 0:
        q = a // b
        a, b = b, a % b
        x0, x1 = x1, x0 - q * x1
        y0, y1 = y1, y0 - q * y1
    return a, x0, y0

def chinese_remainder_theorem(congruences):
    x, M = 0, 1
    for _, m in congruences:
        M *= m

    for a, m in congruences:
        Mi = M // m
        gcd, mi_inv, _ = gcd_extended(Mi, m)
        if gcd != 1:
            return None  # No solution exists if gcd is not 1
        x += a * Mi * mi_inv
    
    return x % M

# Input and Output
n = int(input("Enter number of congruences n: "))
congruences = []
for i in range(n):
    a, m = map(int, input(f"Enter a_i and m_i for congruence {i+1} (a_i m_i): ").split())
    congruences.append((a, m))

# Check if system has a solution
result = chinese_remainder_theorem(congruences)
if result is None:
    print("No solution exists for the system of congruences.")
else:
    print(f"Solution to the system of congruences is x = {result}")
