def modular_exponentiation(a, x, n):
    result = 1
    base = a % n  # Initial base
    print(f"Initial: base = {base}, exponent = {x}, modulus = {n}")

    while x > 0:
        if x % 2 == 1:  # If exponent is odd
            result = (result * base) % n
            print(f"Odd exponent: result = (result * base) % n = {result}")
        base = (base * base) % n  # Square the base
        print(f"Base squared: base = (base * base) % n = {base}")
        x //= 2  # Halve the exponent
        print(f"Exponent halved: x = {x}")

    return result

# Input and Output
a = int(input("Enter base a: "))
x = int(input("Enter exponent x: "))
n = int(input("Enter modulus n: "))

if n <= 0:
    print("Error: Modulus n must be positive.")
else:
    result = modular_exponentiation(a, x, n)
    print(f"{a}^{x} (mod {n}) = {result}")
