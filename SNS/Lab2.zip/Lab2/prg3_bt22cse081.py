def prime_factors(n):
    factors = []
    divisor = 2
    while n > 1:
        while n % divisor == 0:
            factors.append(divisor)
            n //= divisor
        divisor += 1
    return factors

# Input and Output
n = int(input("Enter an integer: "))

if n <= 0:
    print("Error: Enter a positive integer.")
else:
    factors = prime_factors(n)
    print("Prime factors (with multiplicity):", *factors)
