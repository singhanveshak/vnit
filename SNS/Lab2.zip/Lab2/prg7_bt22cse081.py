def gcd_extended(a, b):
    x0, x1, y0, y1 = 1, 0, 0, 1
    while b != 0:
        q = a // b
        a, b = b, a % b
        x0, x1 = x1, x0 - q * x1
        y0, y1 = y1, y0 - q * y1
    return a, x0, y0

def solve_congruence(a, b, m):
    gcd, x, _ = gcd_extended(a, m)
    if b % gcd != 0:
        return False, None  # No solution exists
    x = (x * (b // gcd)) % m
    solutions = []
    for i in range(gcd):
        solutions.append((x + i * (m // gcd)) % m)
    return True, solutions

# Input and Output
a = int(input("Enter coefficient a: "))
b = int(input("Enter value b: "))
m = int(input("Enter modulus m: "))

if m <= 0:
    print("Error: Modulus m must be positive.")
else:
    exists, solutions = solve_congruence(a, b, m)
    if not exists:
        print(f"No solution exists for {a}x ≡ {b} (mod {m}).")
    else:
        print(f"Solutions to {a}x ≡ {b} (mod {m}):")
        print(f"Number of solutions: {len(solutions)}")
        print("Solutions:", *solutions)
        
        
'''
The equation has a solution if and only if:
gcd⁡(a,m)∣b

Use the Extended Euclidean Algorithm to find one particular solution x0 using:
ax0 ≡ gcd⁡(a,m) (mod m)
ax0​ ≡ gcd(a,m) (mod m)
Then, all solutions are given by:
x = x0 + k × m / gcd⁡(a,m),for k∈Z

'''
