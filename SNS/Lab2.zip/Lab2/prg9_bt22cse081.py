def gcd(a, b):
    while b:
        a, b = b, a % b
    return a

def order_of_a_mod_m(a, m):
    if gcd(a, m) != 1:
        return -1  # No order if a and m are not coprime
    
    order = 1
    current_power = a % m
    while current_power != 1:
        current_power = (current_power * a) % m
        order += 1
    
    return order

# Input and Output
a = int(input("Enter integer a: "))
m = int(input("Enter modulus m: "))

if m <= 0:
    print("Error: Modulus m must be positive.")
else:
    order = order_of_a_mod_m(a, m)
    if order == -1:
        print(f"The order of {a} modulo {m} does not exist (a and m are not coprime).")
    else:
        print(f"The order of {a} modulo {m} is {order}.")
        
        
'''
order of a modulo m, which is the smallest positive integer k such that:
a^k≡1 (mod m)

'''
