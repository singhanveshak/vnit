def extended_euclidean(a, b):
    # Initialize variables
    x0, x1, y0, y1 = 1, 0, 0, 1

    while b != 0:
        q = a // b  # Quotient
        a, b = b, a % b  # Update a and b
        x0, x1 = x1, x0 - q * x1  # Update x
        y0, y1 = y1, y0 - q * y1  # Update y

    return a, x0, y0  # gcd(a, b), x, y

# Input and Output
a = int(input("Enter integer a: "))
b = int(input("Enter integer b: "))

gcd, x, y = extended_euclidean(a, b)
if x > y:
    x, y = y, x  # Ensure x < y as per requirement

print(f"gcd({a}, {b}) = {gcd}")
print(f"Solution to {a}x + {b}y = {gcd}: x = {x}, y = {y}")
