def gcd(a, b):
    while b:
        a, b = b, a % b
    return a

def find_common_divisors(numbers):
    # Compute GCD of all numbers
    n = len(numbers)
    result = numbers[0]
    for i in range(1, n):
        result = gcd(result, numbers[i])
    
    # Find all divisors of the GCD
    divisors = []
    for i in range(1, result + 1):
        if result % i == 0:
            divisors.append(i)
    return divisors

# Input and Output
n = int(input("Enter the number of integers (n): "))
numbers = list(map(int, input(f"Enter {n} integers separated by space: ").split()))

if len(numbers) != n:
    print("Error: Number of integers does not match n.")
else:
    divisors = find_common_divisors(numbers)
    print("Common divisors:", *divisors)
