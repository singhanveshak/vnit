import sys

# Custom character set
CHARSET = "0123456789 abcdefghijklmnopqrstuvwxyz"
# Hardcoded Rotor mapping (first 25 distinct characters of full name + numbers)
K_trad = "syedtaqiluzfgvbrjmwchkxnyo0123456789"  # Example key
ROTOR_MAP = {CHARSET[i]: K_trad[i] for i in range(len(CHARSET))}  # Encoding map
REV_ROTOR_MAP = {v: k for k, v in ROTOR_MAP.items()}  # Decoding map

# Encrypt plaintext using Rotor Cipher
def rotor_encrypt(plaintext):
    return "".join(ROTOR_MAP.get(c, c) for c in plaintext).upper()

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: python3 prg7.py <plaintext>")
        sys.exit(1)

    plaintext = " ".join(sys.argv[1:]).lower()
    ciphertext = rotor_encrypt(plaintext)

    print(ciphertext)
