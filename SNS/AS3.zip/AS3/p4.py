import sys

# Custom 5x5 Playfair matrix key (first 25 distinct characters of full name)
K_trad = "syedtaqiluzfgvbrkmwchnxoy"  # Example key

# Prepare Playfair matrix
def create_playfair_matrix(key):
    matrix = []
    seen = set()
    for char in key:
        if char not in seen:
            matrix.append(char)
            seen.add(char)
    return matrix

# Find position of a character in Playfair matrix
def find_position(matrix, char):
    index = matrix.index(char)
    return index // 5, index % 5

# Encrypt a digraph
def playfair_encrypt_digraph(matrix, a, b):
    row1, col1 = find_position(matrix, a)
    row2, col2 = find_position(matrix, b)

    if row1 == row2:  # Same row
        return matrix[row1 * 5 + (col1 + 1) % 5] + matrix[row2 * 5 + (col2 + 1) % 5]
    elif col1 == col2:  # Same column
        return matrix[((row1 + 1) % 5) * 5 + col1] + matrix[((row2 + 1) % 5) * 5 + col2]
    else:  # Rectangle swap
        return matrix[row1 * 5 + col2] + matrix[row2 * 5 + col1]

# Encrypt the text using Playfair cipher
def playfair_encrypt(plaintext, matrix):
    plaintext = plaintext.replace("j", "i")  # Treat 'i' and 'j' as same
    text_pairs = []
    i = 0
    while i < len(plaintext):
        a = plaintext[i]
        b = plaintext[i + 1] if i + 1 < len(plaintext) and plaintext[i] != plaintext[i + 1] else 'x'
        text_pairs.append(a + b)
        i += 2 if i + 1 < len(plaintext) and a != b else 1

    ciphertext = "".join(playfair_encrypt_digraph(matrix, a, b) for a, b in text_pairs)
    return ciphertext.upper()

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: python3 prg4.py <plaintext>")
        sys.exit(1)

    matrix = create_playfair_matrix(K_trad)
    plaintext = "".join(sys.argv[1:]).lower().replace(" ", "")
    ciphertext = playfair_encrypt(plaintext, matrix)

    print(ciphertext, "CO1 CO3")
