import sys

# Custom character set
CHARSET = "0123456789 abcdefghijklmnopqrstuvwxyz"
CHAR_MAP = {c: i for i, c in enumerate(CHARSET)}  # Mapping char -> index
REV_MAP = {i: c for i, c in enumerate(CHARSET)}  # Mapping index -> char

# Hardcoded key (first 25 distinct characters of full name)
K_trad = "syedtaqiluzfgvbrkmwchnxoy"  # Example key

def vigenere_encrypt(plaintext, key):
    ciphertext = ""
    key_stream = [CHAR_MAP[key[i % len(key)]] for i in range(len(plaintext))]

    for i, char in enumerate(plaintext):
        if char in CHAR_MAP:
            new_index = (CHAR_MAP[char] + key_stream[i]) % len(CHARSET)
            ciphertext += REV_MAP[new_index]
        else:
            ciphertext += char
    return ciphertext.upper()

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: python3 prg5.py <plaintext>")
        sys.exit(1)

    plaintext = " ".join(sys.argv[1:]).lower()
    ciphertext = vigenere_encrypt(plaintext, K_trad)

    print(ciphertext)
