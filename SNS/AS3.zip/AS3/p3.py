import sys

# Custom character set
CHARSET = "0123456789 abcdefghijklmnopqrstuvwxyz"
CHAR_MAP = {c: i for i, c in enumerate(CHARSET)}  # Mapping char -> index
REV_MAP = {i: c for i, c in enumerate(CHARSET)}  # Mapping index -> char

# Hardcoded initial key (last digit of roll number)
K_roll1 = 3  # Change as per roll number

def autokey_encrypt(plaintext, key):
    ciphertext = ""
    key_stream = [key] + [CHAR_MAP[c] for c in plaintext]

    for i, char in enumerate(plaintext):
        if char in CHAR_MAP:
            new_index = (CHAR_MAP[char] + key_stream[i]) % len(CHARSET)
            ciphertext += REV_MAP[new_index]
        else:
            ciphertext += char
    return ciphertext.upper()

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: python3 prg3.py <plaintext>")
        sys.exit(1)

    plaintext = " ".join(sys.argv[1:]).lower()
    ciphertext = autokey_encrypt(plaintext, K_roll1)

    print(ciphertext)
