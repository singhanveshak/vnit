import sys
import math

# Encrypt using Keyless Transposition Cipher
def transposition_encrypt(plaintext):
    length = len(plaintext)
    size = math.ceil(math.sqrt(length))  # Determine grid size
    grid = [['' for _ in range(size)] for _ in range(size)]

    # Fill grid row-wise
    index = 0
    for i in range(size):
        for j in range(size):
            if index < length:
                grid[i][j] = plaintext[index]
                index += 1

    # Read grid column-wise
    ciphertext = "".join(grid[j][i] for i in range(size) for j in range(size) if grid[j][i])
    return ciphertext.upper()

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: python3 prg9.py <plaintext>")
        sys.exit(1)

    plaintext = " ".join(sys.argv[1:]).lower().replace(" ", "")
    ciphertext = transposition_encrypt(plaintext)

    print(ciphertext)
