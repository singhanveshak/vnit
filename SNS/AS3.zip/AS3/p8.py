import sys

# Encrypt using Rail Fence Cipher
def rail_fence_encrypt(plaintext):
    rail1, rail2 = "", ""

    for i, char in enumerate(plaintext):
        if i % 2 == 0:
            rail1 += char
        else:
            rail2 += char

    return (rail1 + rail2).upper()

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: python3 prg8.py <plaintext>")
        sys.exit(1)

    plaintext = " ".join(sys.argv[1:]).lower().replace(" ", "")
    ciphertext = rail_fence_encrypt(plaintext)

    print(ciphertext)
