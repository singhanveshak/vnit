import sys

# Custom character set
CHARSET = "0123456789 abcdefghijklmnopqrstuvwxyz"
CHAR_MAP = {c: i for i, c in enumerate(CHARSET)}  # Mapping char -> index
REV_MAP = {i: c for i, c in enumerate(CHARSET)}  # Mapping index -> char

# Hardcoded key (last digit of roll number)
K_roll1 = 3  # Change this as per roll number

def caesar_cipher_encrypt(plaintext, shift):
    ciphertext = ""
    for char in plaintext:
        if char in CHAR_MAP:
            new_index = (CHAR_MAP[char] + shift) % len(CHARSET)
            ciphertext += REV_MAP[new_index]
        else:
            ciphertext += char  # Keep unknown characters unchanged
    return ciphertext.upper()

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: python3 prg1.py <plaintext>")
        sys.exit(1)

    plaintext = " ".join(sys.argv[1:]).lower()  # Convert input to lowercase
    ciphertext = caesar_cipher_encrypt(plaintext, K_roll1)
    
    print(ciphertext)