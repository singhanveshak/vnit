import sys

# Custom character set
CHARSET = "0123456789 abcdefghijklmnopqrstuvwxyz"
CHAR_MAP = {c: i for i, c in enumerate(CHARSET)}  # Mapping char -> index
REV_MAP = {i: c for i, c in enumerate(CHARSET)}  # Mapping index -> char

# Hardcoded keys (must be adjusted per roll number)
K_roll1 = 5  # Must be coprime to 36 (e.g., 1, 5, 7, 11, 17, 19, 23, 25, 29, 31, 35)
K_roll2 = 3  # Any number from 0 to 35

# Function to find modular inverse (for decryption)
def mod_inverse(a, m):
    for x in range(1, m):
        if (a * x) % m == 1:
            return x
    return None  # No inverse exists

# Affine Cipher Encryption
def affine_encrypt(plaintext, k1, k2):
    ciphertext = ""
    for char in plaintext:
        if char in CHAR_MAP:
            new_index = (k1 * CHAR_MAP[char] + k2) % len(CHARSET)
            ciphertext += REV_MAP[new_index]
        else:
            ciphertext += char  # Keep unknown characters unchanged
    return ciphertext.upper()

# Affine Cipher Decryption
def affine_decrypt(ciphertext, k1, k2):
    plaintext = ""
    k1_inv = mod_inverse(k1, len(CHARSET))  # Compute modular inverse
    if k1_inv is None:
        return "Error: k1 has no modular inverse. Choose a different k1."

    for char in ciphertext.lower():
        if char in CHAR_MAP:
            new_index = (k1_inv * (CHAR_MAP[char] - k2)) % len(CHARSET)
            plaintext += REV_MAP[new_index]
        else:
            plaintext += char
    return plaintext

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: python3 prg2.py <plaintext>")
        sys.exit(1)

    plaintext = " ".join(sys.argv[1:]).lower()
    ciphertext = affine_encrypt(plaintext, K_roll1, K_roll2)

    print(ciphertext)
