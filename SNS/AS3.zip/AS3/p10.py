import sys

# Custom character set and permutation table
CHARSET = "0123456789 abcdefghijklmnopqrstuvwxyz"
K_trad = "syedtaqiluzfgvbrjmwchkxnyo0123456789"  # Example key

# Generate numeric permutation table based on K_trad
PERMUTATION_TABLE = [K_trad.index(c) for c in CHARSET]

# Encrypt using Keyed Transposition Cipher
def keyed_transposition_encrypt(plaintext):
    plaintext = plaintext.replace(" ", "")  # Remove spaces
    length = len(plaintext)
    sorted_indices = sorted(range(length), key=lambda x: PERMUTATION_TABLE[x % len(PERMUTATION_TABLE)])

    ciphertext = "".join(plaintext[i] for i in sorted_indices)
    return ciphertext.upper()

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: python3 prg10.py <plaintext>")
        sys.exit(1)

    plaintext = "".join(sys.argv[1:]).lower()
    ciphertext = keyed_transposition_encrypt(plaintext)

    print(ciphertext)
