import sys

# Custom character set
CHARSET = "0123456789 abcdefghijklmnopqrstuvwxyz"
CHAR_MAP = {c: i for i, c in enumerate(CHARSET)}  # Mapping char -> index
REV_MAP = {i: c for i, c in enumerate(CHARSET)}  # Mapping index -> char

# Hardcoded 5x5 matrix key (first 25 distinct characters of full name)
K_trad = "syedtaqiluzfgvbrkmwchnxoy"  # Example key
KEY_MATRIX_SIZE = 5

# Convert key into a 5x5 matrix
def create_key_matrix(key):
    return [[CHAR_MAP[key[i * KEY_MATRIX_SIZE + j]] for j in range(KEY_MATRIX_SIZE)] for i in range(KEY_MATRIX_SIZE)]

# Multiply matrix with text vector
def matrix_multiply(matrix, vector):
    result = [0] * KEY_MATRIX_SIZE
    for i in range(KEY_MATRIX_SIZE):
        result[i] = sum(matrix[i][j] * vector[j] for j in range(KEY_MATRIX_SIZE)) % len(CHARSET)
    return result

# Encrypt plaintext using Hill Cipher
def hill_encrypt(plaintext, matrix):
    plaintext = plaintext.replace(" ", "")  # Remove spaces
    while len(plaintext) % KEY_MATRIX_SIZE != 0:
        plaintext += "x"  # Padding

    ciphertext = ""
    for i in range(0, len(plaintext), KEY_MATRIX_SIZE):
        block = [CHAR_MAP[plaintext[j]] for j in range(i, i + KEY_MATRIX_SIZE)]
        encrypted_block = matrix_multiply(matrix, block)
        ciphertext += "".join(REV_MAP[idx] for idx in encrypted_block)

    return ciphertext.upper()

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: python3 prg6.py <plaintext>")
        sys.exit(1)

    key_matrix = create_key_matrix(K_trad)
    plaintext = "".join(sys.argv[1:]).lower()
    ciphertext = hill_encrypt(plaintext, key_matrix)

    print(ciphertext)
