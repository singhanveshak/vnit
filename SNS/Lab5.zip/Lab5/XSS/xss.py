from flask import Flask, request

app = Flask(__name__)

@app.route('/', methods=['GET'])
def blank():
    name = request.args.get('name', '')
    return f"Nothing here, {name}"

@app.route('/xss', methods=['GET'])
def xss():
    name = request.args.get('name', '')
    return f"Yay! You have been hacked"

if __name__ == '__main__':
    app.run(debug=True)
# http://127.0.0.1:5000/xss?name=<script>alert('XSS');</script>

