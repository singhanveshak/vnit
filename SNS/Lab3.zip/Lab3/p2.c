#include <stdio.h>
#include <gmp.h>
#include <time.h>

void elgamal_keygen(mpz_t p, mpz_t g, mpz_t x, mpz_t h, unsigned int bits) {
    gmp_randstate_t state;
    gmp_randinit_default(state);
    gmp_randseed_ui(state, time(NULL));

    // Generate large prime p
    mpz_urandomb(p, state, bits);
    mpz_nextprime(p, p);

    // Choose generator g
    mpz_urandomm(g, state, p);
    while (mpz_cmp_ui(g, 2) < 0) {
        mpz_urandomm(g, state, p);
    }

    // Choose private key x < p
    mpz_urandomm(x, state, p);
    
    // Compute public key h = g^x mod p
    mpz_powm(h, g, x, p);
}

void elgamal_encrypt(mpz_t c1, mpz_t c2, mpz_t m, mpz_t g, mpz_t h, mpz_t p) {
    gmp_randstate_t state;
    mpz_t k;
    mpz_init(k);

    gmp_randinit_default(state);
    gmp_randseed_ui(state, time(NULL));
    
    // Choose random k < p
    mpz_urandomm(k, state, p);

    // c1 = g^k mod p
    mpz_powm(c1, g, k, p);

    // c2 = m * h^k mod p
    mpz_powm(c2, h, k, p);
    mpz_mul(c2, c2, m);
    mpz_mod(c2, c2, p);

    mpz_clear(k);
}

void elgamal_decrypt(mpz_t m, mpz_t c1, mpz_t c2, mpz_t x, mpz_t p) {
    mpz_t s;
    mpz_init(s);

    // s = c1^x mod p
    mpz_powm(s, c1, x, p);

    // m = c2 * s^(-1) mod p
    mpz_invert(s, s, p);
    mpz_mul(m, c2, s);
    mpz_mod(m, m, p);

    mpz_clear(s);
}

int main() {
    mpz_t p, g, x, h, m, c1, c2, decrypted;
    mpz_inits(p, g, x, h, m, c1, c2, decrypted, NULL);

    elgamal_keygen(p, g, x, h, 256);

    gmp_printf("Public key (p, g, h) = (%Zd, %Zd, %Zd)\n", p, g, h);
    gmp_printf("Private key x = %Zd\n", x);

    // Input message
    mpz_set_ui(m, 42);
    gmp_printf("Plaintext = %Zd\n", m);

    // Encrypt
    elgamal_encrypt(c1, c2, m, g, h, p);
    gmp_printf("Ciphertext = (%Zd, %Zd)\n", c1, c2);

    // Decrypt
    elgamal_decrypt(decrypted, c1, c2, x, p);
    gmp_printf("Decrypted plaintext = %Zd\n", decrypted);

    mpz_clears(p, g, x, h, m, c1, c2, decrypted, NULL);
    return 0;
}

