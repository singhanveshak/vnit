#include <stdio.h>
#include <gmp.h>
#include <time.h>

void rsa_keygen(mpz_t n, mpz_t e, mpz_t d, unsigned int bits) {
    mpz_t p, q, phi, gcd;
    gmp_randstate_t state;
    gmp_randinit_default(state);
    gmp_randseed_ui(state, time(NULL));

    mpz_inits(p, q, phi, gcd, NULL);

    // Generate two large prime numbers p and q
    mpz_urandomb(p, state, bits / 2);
    mpz_nextprime(p, p);

    mpz_urandomb(q, state, bits / 2);
    mpz_nextprime(q, q);

    // n = p * q
    mpz_mul(n, p, q);

    // phi = (p-1)(q-1)
    mpz_sub_ui(p, p, 1);
    mpz_sub_ui(q, q, 1);
    mpz_mul(phi, p, q);

    // Choose e such that gcd(e, phi) = 1
    mpz_set_ui(e, 65537); // Common public exponent

    mpz_gcd(gcd, e, phi);
    while (mpz_cmp_ui(gcd, 1) != 0) {
        mpz_add_ui(e, e, 2);
        mpz_gcd(gcd, e, phi);
    }

    // Compute d = e^(-1) mod phi
    mpz_invert(d, e, phi);

    mpz_clears(p, q, phi, gcd, NULL);
}

void rsa_encrypt(mpz_t ciphertext, mpz_t plaintext, mpz_t e, mpz_t n) {
    mpz_powm(ciphertext, plaintext, e, n);
}

void rsa_decrypt(mpz_t plaintext, mpz_t ciphertext, mpz_t d, mpz_t n) {
    mpz_powm(plaintext, ciphertext, d, n);
}

int main() {
    mpz_t n, e, d, plaintext, ciphertext, decrypted;
    mpz_inits(n, e, d, plaintext, ciphertext, decrypted, NULL);

    rsa_keygen(n, e, d, 512);

    gmp_printf("Public key (n, e) = (%Zd, %Zd)\n", n, e);
    gmp_printf("Private key (n, d) = (%Zd, %Zd)\n", n, d);

    // Input plaintext
    mpz_set_ui(plaintext, 42);
    gmp_printf("Plaintext = %Zd\n", plaintext);

    // Encrypt
    rsa_encrypt(ciphertext, plaintext, e, n);
    gmp_printf("Ciphertext = %Zd\n", ciphertext);

    // Decrypt
    rsa_decrypt(decrypted, ciphertext, d, n);
    gmp_printf("Decrypted plaintext = %Zd\n", decrypted);

    mpz_clears(n, e, d, plaintext, ciphertext, decrypted, NULL);
    return 0;
}
