#include <stdio.h>
#include <gmp.h>
#include <string.h>
#include <time.h>

void hash_message(mpz_t hash, const char *message) {
    mpz_set_ui(hash, 0);
    for (size_t i = 0; i < strlen(message); i++) {
        mpz_mul_ui(hash, hash, 256);
        mpz_add_ui(hash, hash, (unsigned char)message[i]);
    }
}

void keygen(mpz_t n, mpz_t e, mpz_t d, unsigned int bits) {
    gmp_randstate_t state;
    mpz_t p, q, phi;

    mpz_inits(p, q, phi, NULL);
    gmp_randinit_default(state);
    gmp_randseed_ui(state, time(NULL));

    // Generate two large primes p and q
    mpz_urandomb(p, state, bits / 2);
    mpz_nextprime(p, p);
    mpz_urandomb(q, state, bits / 2);
    mpz_nextprime(q, q);

    // n = p * q
    mpz_mul(n, p, q);

    // phi(n) = (p-1) * (q-1)
    mpz_sub_ui(p, p, 1);
    mpz_sub_ui(q, q, 1);
    mpz_mul(phi, p, q);

    // Set public exponent e
    mpz_set_ui(e, 65537);

    // Compute private exponent d (d = e^(-1) mod phi)
    mpz_invert(d, e, phi);

    mpz_clears(p, q, phi, NULL);
}

void sign(mpz_t sig, mpz_t hash, mpz_t d, mpz_t n) {
    mpz_powm(sig, hash, d, n);
}

int verify(mpz_t sig, mpz_t hash, mpz_t e, mpz_t n) {
    mpz_t v;
    mpz_init(v);

    // v = sig^e mod n
    mpz_powm(v, sig, e, n);

    int result = mpz_cmp(v, hash) == 0;
    mpz_clear(v);
    return result;
}

int main() {
    mpz_t n, e, d, hash, sig;
    mpz_inits(n, e, d, hash, sig, NULL);

    // Generate keys
    keygen(n, e, d, 512);
    gmp_printf("Public key: (n = %Zd, e = %Zd)\n", n, e);
    gmp_printf("Private key: d = %Zd\n", d);

    // Hash message
    const char *message = "FDH Signature Scheme";
    hash_message(hash, message);
    gmp_printf("Hash of message: %Zd\n", hash);

    // Sign the message
    sign(sig, hash, d, n);
    gmp_printf("Signature: %Zd\n", sig);

    // Verify the signature
    if (verify(sig, hash, e, n)) {
        printf("Signature is valid!\n");
    } else {
        printf("Invalid signature!\n");
    }

    mpz_clears(n, e, d, hash, sig, NULL);
    return 0;
}


