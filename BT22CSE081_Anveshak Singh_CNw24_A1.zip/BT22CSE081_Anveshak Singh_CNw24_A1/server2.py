import socket
import threading

def evaluate_expression(expression):
    try:
        result = eval(expression)
        return str(result)
    except Exception as e:
        return "Invalid Input"

def handle_client(client_socket, addr):
    print(f"Connected with client {addr}")
    while True:
        try:
            data = client_socket.recv(1024).decode()
            if not data:
                break
            print(f"Received from client {addr}: {data}")
            result = evaluate_expression(data)   #vulnerable to command injection !!!
            client_socket.send(result.encode())
        except:
            break

    client_socket.close()
    print(f"Client {addr} disconnected")

def start_server(host, port):
    server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server_socket.bind((host, port))
    server_socket.listen(5)
    print(f"Server started on {host}:{port}")

    try:
        while True:
            client_socket, addr = server_socket.accept()
            client_thread = threading.Thread(target=handle_client, args=(client_socket, addr))
            client_thread.start()

    except KeyboardInterrupt:
        print("Server shutting down...")
        server_socket.close()

if __name__ == "__main__":
    import sys
    if len(sys.argv) != 3:
        print("Usage: python server2.py <server_ip> <port>")
        sys.exit(1)

    host = sys.argv[1]
    port = int(sys.argv[2])
    start_server(host, port)
