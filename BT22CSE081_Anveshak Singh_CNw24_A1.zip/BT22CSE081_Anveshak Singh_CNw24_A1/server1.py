import socket

def evaluate_expression(expression):
    try:
        result = eval(expression)
        return str(result)
    except Exception as e:
        return "Invalid Input"

def start_server(host, port):
    server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server_socket.bind((host, port))
    server_socket.listen(1)
    print(f"Server started listening on {host}:{port}")

    while True:
        try:
            client_socket, addr = server_socket.accept()
            print(f"Connected with client {addr}")

            while True:
                data = client_socket.recv(1024).decode()
                if not data:
                    break
                print(f"Log: incoming: {data}")
                result = evaluate_expression(data)      #vulnerable to command injection !!!          
                client_socket.send(result.encode())
                print(f"Log: outgoing: {data}")

            client_socket.close()
            print(f"Client {addr} disconnected")

        except KeyboardInterrupt:
            print("Server shutting down...")
            server_socket.close()
            break

if __name__ == "__main__":
    import sys
    if len(sys.argv) != 3:
        print("Usage: python server1.py <server_ip> <port>")
        sys.exit(1)

    host = sys.argv[1]
    port = int(sys.argv[2])
    start_server(host, port)
