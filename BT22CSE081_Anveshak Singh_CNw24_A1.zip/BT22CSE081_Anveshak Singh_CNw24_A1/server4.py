import socket
import select

def start_server(host, port):
    server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server_socket.bind((host, port))
    server_socket.listen(5)
    print(f"Server started on {host}:{port}")

    sockets_list = [server_socket]

    try:
        while True:
            read_sockets, _, _ = select.select(sockets_list, [], [])
            
            for sock in read_sockets:
                if sock == server_socket:
                    client_socket, addr = server_socket.accept()
                    print(f"New connection from {addr}")
                    sockets_list.append(client_socket)
                else:
                    try:
                        data = sock.recv(1024).decode()
                        if not data:
                            print("Connection closed")
                            sockets_list.remove(sock)
                            sock.close()
                            continue

                        print(f"Echoing: {data}")
                        sock.send(data.encode())
                    except:
                        sockets_list.remove(sock)
                        sock.close()

    except KeyboardInterrupt:
        print("Server shutting down...")
        server_socket.close()

if __name__ == "__main__":
    import sys
    if len(sys.argv) != 3:
        print("Usage: python server4.py <server_ip> <port>")
        sys.exit(1)

    host = sys.argv[1]
    port = int(sys.argv[2])
    start_server(host, port)
