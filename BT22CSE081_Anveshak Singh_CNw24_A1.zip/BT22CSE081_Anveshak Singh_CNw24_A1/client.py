import socket
import sys

def start_client(host, port):
    client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    client_socket.connect((host, port))
    print("Connected to server")

    try:
        while True:
            message = input("Enter arithmetic expression (e.g., 5 + 3): ")
            client_socket.send(message.encode())
            response = client_socket.recv(1024).decode()
            print(f"Server replied: {response}")

    except KeyboardInterrupt:
        print("\nClient exiting...")

    client_socket.close()

if __name__ == "__main__":
    if len(sys.argv) != 3:
        print("Usage: python client.py <server_ip> <port>")
        sys.exit(1)
        
    host = sys.argv[1]
    port = int(sys.argv[2])
    start_client(host, port)
